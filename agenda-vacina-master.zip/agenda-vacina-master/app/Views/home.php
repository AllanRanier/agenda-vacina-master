<h3>sessão</h3>

<hr>

<p><?php echo session()->usuario ?></p>